ARCHIVED BRANCHES — pre-nuke backup, 2026-05-13
================================================

This bundle is a backup of three remote branches that were deleted from
origin on 2026-05-13 as part of cleaning up the repository to a single
working branch (claude/continue-ptl-timesheet-blVcV).

Branches preserved in this bundle
---------------------------------

1. refs/remotes/origin/claude/timesheet-web-app-phase-2-LE9yj
     - Earlier Claude session's working branch.
     - Had ZERO unique commits at time of deletion (every commit on it
       was already present on claude/continue-ptl-timesheet-blVcV).
     - Safe to delete; preserved here for completeness.

2. refs/remotes/origin/update_worker_name_to_temporium
     - One unique commit (28abc22): "Update wrangler config name to
       temporium".
     - This branch was almost certainly what Cloudflare Workers was
       deploying from in production until 2026-05-13 (the live worker
       in the dashboard was called "temporium").

3. refs/remotes/origin/update_worker_name_to_ptl-timesheet
     - One unique commit (4bd23f8): "Update wrangler config name to
       ptl-timesheet".
     - Competing rename, never deployed.

Also bundled for reference (NOT deleted):

4. refs/remotes/origin/claude/continue-ptl-timesheet-blVcV
     - The branch we kept as the canonical working branch.

How to restore
--------------

If you need any of these branches back, from inside this repo:

    # See what's in the bundle:
    git bundle list-heads archive/branches-pre-nuke-2026-05-13.bundle

    # Restore one branch as a local working branch:
    git fetch archive/branches-pre-nuke-2026-05-13.bundle \
        refs/remotes/origin/update_worker_name_to_temporium:restored-temporium

    # Then push back to origin if you actually want it remote again:
    git push origin restored-temporium

The bundle is self-contained — it carries every commit object reachable
from the listed refs, so it works even after the GitHub-side branches
are gone.
